import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../models/media_item.dart';
import '../screens/detail_screen.dart';

class MediaCard extends StatelessWidget {
  final MediaItem item;
  const MediaCard({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailScreen(item: item))),
      borderRadius: BorderRadius.circular(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: CachedNetworkImage(
              imageUrl: item.posterUrl,
              width: double.infinity,
              fit: BoxFit.cover,
              placeholder: (_, __) => const ColoredBox(color: Color(0xFF202020)),
              errorWidget: (_, __, ___) => const ColoredBox(color: Color(0xFF202020), child: Icon(Icons.movie)),
            ),
          ),
        ),
        const SizedBox(height: 7),
        Text(item.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
        Text('${item.year}', style: const TextStyle(color: Colors.white60, fontSize: 12)),
      ]),
    );
  }
}
