import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/media_item.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Stream<List<MediaItem>> media({String? category}) {
    Query<Map<String, dynamic>> q = _db.collection('media').orderBy('createdAt', descending: true);
    if (category != null) q = q.where('category', isEqualTo: category);
    return q.snapshots().map((s) => s.docs.map(MediaItem.fromDoc).toList());
  }

  Future<void> addMedia(MediaItem item) => _db.collection('media').add(item.toMap());

  Future<void> toggleFavorite(String mediaId) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) throw Exception('Debes iniciar sesión');
    final ref = _db.collection('users').doc(uid).collection('favorites').doc(mediaId);
    final snap = await ref.get();
    if (snap.exists) {
      await ref.delete();
    } else {
      await ref.set({'mediaId': mediaId, 'createdAt': FieldValue.serverTimestamp()});
    }
  }

  Stream<bool> isFavorite(String mediaId) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return Stream.value(false);
    return _db.collection('users').doc(uid).collection('favorites').doc(mediaId).snapshots().map((d) => d.exists);
  }

  Future<bool> isAdmin() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return false;
    final doc = await _db.collection('users').doc(user.uid).get();
    return doc.data()?['role'] == 'admin';
  }

  Future<bool> isPremium() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return false;
    final doc = await _db.collection('users').doc(user.uid).get();
    return doc.data()?['plan'] == 'premium';
  }
}
