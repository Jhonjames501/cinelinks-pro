import 'package:cloud_firestore/cloud_firestore.dart';

class MediaItem {
  final String id;
  final String title;
  final String description;
  final String posterUrl;
  final String videoUrl;
  final String category;
  final String genre;
  final int year;
  final bool premiumOnly;
  final DateTime? createdAt;

  const MediaItem({
    required this.id,
    required this.title,
    required this.description,
    required this.posterUrl,
    required this.videoUrl,
    required this.category,
    required this.genre,
    required this.year,
    this.premiumOnly = false,
    this.createdAt,
  });

  factory MediaItem.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? {};
    return MediaItem(
      id: doc.id,
      title: d['title'] ?? '',
      description: d['description'] ?? '',
      posterUrl: d['posterUrl'] ?? '',
      videoUrl: d['videoUrl'] ?? '',
      category: d['category'] ?? 'Películas',
      genre: d['genre'] ?? 'General',
      year: (d['year'] as num?)?.toInt() ?? 0,
      premiumOnly: d['premiumOnly'] == true,
      createdAt: (d['createdAt'] as Timestamp?)?.toDate(),
    );
  }

  Map<String, dynamic> toMap() => {
        'title': title,
        'description': description,
        'posterUrl': posterUrl,
        'videoUrl': videoUrl,
        'category': category,
        'genre': genre,
        'year': year,
        'premiumOnly': premiumOnly,
        'createdAt': FieldValue.serverTimestamp(),
      };
}
