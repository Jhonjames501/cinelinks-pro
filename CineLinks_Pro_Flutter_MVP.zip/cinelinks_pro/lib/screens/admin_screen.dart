import 'package:flutter/material.dart';
import '../models/media_item.dart';
import '../services/firestore_service.dart';

class AdminScreen extends StatefulWidget { const AdminScreen({super.key}); @override State<AdminScreen> createState()=>_AdminScreenState(); }
class _AdminScreenState extends State<AdminScreen>{
  final title=TextEditingController(), desc=TextEditingController(), poster=TextEditingController(), video=TextEditingController(), genre=TextEditingController(), year=TextEditingController();
  String category='Películas'; bool premium=false, saving=false; final service=FirestoreService();
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Admin • CineLinks Pro')),body:ListView(padding:const EdgeInsets.all(20),children:[
    _f(title,'Título'),_f(desc,'Descripción',3),_f(poster,'Portada URL'),_f(video,'Link de video URL'),_f(genre,'Género'),_f(year,'Año'),
    DropdownButtonFormField<String>(value:category,items:['Películas','Series','Anime','Documentales'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>category=v!)),
    SwitchListTile(value:premium,onChanged:(v)=>setState(()=>premium=v),title:const Text('Solo Premium')), const SizedBox(height:16),
    FilledButton.icon(icon:const Icon(Icons.cloud_upload),label:const Text('GUARDAR EN FIREBASE'),onPressed:saving?null:()async{setState(()=>saving=true);try{await service.addMedia(MediaItem(id:'',title:title.text,description:desc.text,posterUrl:poster.text,videoUrl:video.text,category:category,genre:genre.text,year:int.tryParse(year.text)??0,premiumOnly:premium));if(mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Contenido guardado')));title.clear();desc.clear();poster.clear();video.clear();genre.clear();year.clear();}}finally{if(mounted)setState(()=>saving=false);}})
  ]));
  Widget _f(TextEditingController c,String label,[int lines=1])=>Padding(padding:const EdgeInsets.only(bottom:12),child:TextField(controller:c,maxLines:lines,decoration:InputDecoration(labelText:label)));
}
