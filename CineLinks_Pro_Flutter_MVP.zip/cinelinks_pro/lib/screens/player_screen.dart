import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class PlayerScreen extends StatefulWidget {
  final String title; final String url;
  const PlayerScreen({super.key, required this.title, required this.url});
  @override State<PlayerScreen> createState()=>_PlayerScreenState();
}
class _PlayerScreenState extends State<PlayerScreen>{
  late final VideoPlayerController c;
  late final Future<void> init;
  @override void initState(){ super.initState(); c=VideoPlayerController.networkUrl(Uri.parse(widget.url)); init=c.initialize().then((_){c.play();}); }
  @override void dispose(){c.dispose(); super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(widget.title)), body:Center(child:FutureBuilder(future:init,builder:(_,s){if(s.connectionState!=ConnectionState.done)return const CircularProgressIndicator();return AspectRatio(aspectRatio:c.value.aspectRatio,child:Stack(alignment:Alignment.center,children:[VideoPlayer(c),IconButton(iconSize:64,icon:Icon(c.value.isPlaying?Icons.pause_circle:Icons.play_circle),onPressed:(){setState(()=>c.value.isPlaying?c.pause():c.play());})]));})));
}
