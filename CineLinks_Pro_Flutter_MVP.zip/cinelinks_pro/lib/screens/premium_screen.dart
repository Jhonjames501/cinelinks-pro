import 'package:flutter/material.dart';

class PremiumScreen extends StatelessWidget {
  const PremiumScreen({super.key});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('CineLinks Pro Premium')),body:ListView(padding:const EdgeInsets.all(20),children:[
    _plan('GRATIS','S/ 0','Con anuncios','Acceso a links gratuitos',false),
    const SizedBox(height:16),
    _plan('PREMIUM','S/ 9.90 / mes','Sin anuncios','Acceso a todos los links',true),
    const SizedBox(height:22),
    const Text('Pagos',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)), const SizedBox(height:8),
    const Text('Los botones deben llamar a un backend/Cloud Function que cree la preferencia u orden de pago. Nunca guardes Client Secret ni access tokens privados dentro de la app.'), const SizedBox(height:16),
    FilledButton(onPressed:()=>_pending(context,'Mercado Pago'),child:const Text('Suscribirse con Mercado Pago')),
    const SizedBox(height:10), OutlinedButton(onPressed:()=>_pending(context,'PayPal'),child:const Text('Suscribirse con PayPal')),
  ]);
  Widget _plan(String name,String price,String a,String b,bool hot)=>Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:const Color(0xFF151515),borderRadius:BorderRadius.circular(18),border:Border.all(color:hot?const Color(0xFFE50914):Colors.white12,width:hot?2:1)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(name,style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900)),Text(price,style:const TextStyle(fontSize:28,fontWeight:FontWeight.w900)),const SizedBox(height:10),Text('• $a\n• $b')]));
  void _pending(BuildContext c,String p)=>ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text('$p: conecta tu endpoint seguro de checkout.')));
}
