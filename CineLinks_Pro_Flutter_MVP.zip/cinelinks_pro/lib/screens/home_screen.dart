import 'package:flutter/material.dart';
import '../models/media_item.dart';
import '../services/firestore_service.dart';
import '../widgets/media_card.dart';
import 'category_screen.dart';
import 'login_screen.dart';
import 'premium_screen.dart';
import 'admin_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final service = FirestoreService();
  String query = '';
  final categories = const ['Películas', 'Series', 'Anime', 'Documentales'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CineLinks Pro', style: TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          IconButton(icon: const Icon(Icons.workspace_premium), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PremiumScreen()))),
          PopupMenuButton<String>(onSelected: (v) async {
            if (v == 'login') Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
            if (v == 'admin') {
              final ok = await service.isAdmin();
              if (!context.mounted) return;
              if (ok) Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminScreen()));
              else ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Acceso restringido a administrador')));
            }
          }, itemBuilder: (_) => const [
            PopupMenuItem(value: 'login', child: Text('Login / Registro')),
            PopupMenuItem(value: 'admin', child: Text('Admin')),
          ])
        ],
      ),
      body: StreamBuilder<List<MediaItem>>(
        stream: service.media(),
        builder: (context, snap) {
          final all = snap.data ?? [];
          final filtered = all.where((m) => m.title.toLowerCase().contains(query.toLowerCase())).toList();
          return CustomScrollView(slivers: [
            SliverToBoxAdapter(child: _hero(context, all.isNotEmpty ? all.first : null)),
            SliverToBoxAdapter(child: Padding(
              padding: const EdgeInsets.all(16),
              child: TextField(onChanged: (v) => setState(() => query = v), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Buscar películas o series...')),
            )),
            SliverToBoxAdapter(child: SizedBox(height: 48, child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 16), scrollDirection: Axis.horizontal,
              itemCount: categories.length, separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (_, i) => ActionChip(label: Text(categories[i]), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CategoryScreen(category: categories[i])))),
            ))),
            SliverPadding(
              padding: const EdgeInsets.all(16),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate((_, i) => MediaCard(item: filtered[i]), childCount: filtered.length),
                gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 190, childAspectRatio: .57, crossAxisSpacing: 12, mainAxisSpacing: 18),
              ),
            )
          ]);
        },
      ),
    );
  }

  Widget _hero(BuildContext context, MediaItem? item) => Container(
    height: 210,
    margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
    decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: const LinearGradient(colors: [Color(0xFFE50914), Color(0xFF3B0003)])),
    padding: const EdgeInsets.all(22),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.end, children: [
      const Text('ESTRENOS DE LA SEMANA', style: TextStyle(letterSpacing: 1.4, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      Text(item?.title ?? 'Agrega tu primer estreno', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
      const SizedBox(height: 4),
      Text(item == null ? 'Tu catálogo aparecerá aquí desde Firebase.' : '${item.year} • ${item.genre}', style: const TextStyle(color: Colors.white70)),
    ]),
  );
}
