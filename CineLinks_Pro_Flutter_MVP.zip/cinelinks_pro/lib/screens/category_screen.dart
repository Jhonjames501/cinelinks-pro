import 'package:flutter/material.dart';
import '../models/media_item.dart';
import '../services/firestore_service.dart';
import 'detail_screen.dart';

class CategoryScreen extends StatefulWidget {
  final String category;
  const CategoryScreen({super.key, required this.category});
  @override State<CategoryScreen> createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen> {
  String genre = 'Todos';
  int? year;
  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.category)),
      body: StreamBuilder<List<MediaItem>>(
        stream: FirestoreService().media(category: widget.category),
        builder: (_, snap) {
          final source = snap.data ?? [];
          final genres = ['Todos', ...{for (final m in source) m.genre}];
          final years = {for (final m in source) m.year}.toList()..sort((a,b)=>b.compareTo(a));
          final items = source.where((m) => (genre == 'Todos' || m.genre == genre) && (year == null || m.year == year)).toList();
          return Column(children: [
            Padding(padding: const EdgeInsets.all(12), child: Row(children: [
              Expanded(child: DropdownButtonFormField<String>(value: genre, items: genres.map((g)=>DropdownMenuItem(value:g, child: Text(g))).toList(), onChanged:(v)=>setState(()=>genre=v!))),
              const SizedBox(width: 10),
              Expanded(child: DropdownButtonFormField<int?>(value: year, hint: const Text('Año'), items: [const DropdownMenuItem<int?>(value:null, child:Text('Todos')), ...years.map((y)=>DropdownMenuItem<int?>(value:y, child:Text('$y')))], onChanged:(v)=>setState(()=>year=v))),
            ])),
            Expanded(child: ListView.separated(
              padding: const EdgeInsets.all(12), itemCount: items.length, separatorBuilder:(_,__)=>const SizedBox(height:10),
              itemBuilder:(_,i){ final m=items[i]; return ListTile(
                tileColor: const Color(0xFF151515), shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(14)),
                leading: ClipRRect(borderRadius:BorderRadius.circular(8), child: Image.network(m.posterUrl, width:60, height:80, fit:BoxFit.cover, errorBuilder:(_,__,___)=>const SizedBox(width:60,child:Icon(Icons.movie)))),
                title: Text(m.title, style:const TextStyle(fontWeight:FontWeight.w800)),
                subtitle: Text(m.description, maxLines:2, overflow:TextOverflow.ellipsis),
                onTap:()=>Navigator.push(context, MaterialPageRoute(builder:(_)=>DetailScreen(item:m))),
              );},
            ))
          ]);
        },
      ),
    );
  }
}
