import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class LoginScreen extends StatefulWidget { const LoginScreen({super.key}); @override State<LoginScreen> createState()=>_LoginScreenState(); }
class _LoginScreenState extends State<LoginScreen>{
  final email=TextEditingController(), pass=TextEditingController(); bool register=false, loading=false; final auth=AuthService();
  Future<void> run(Future<void> Function() fn) async { setState(()=>loading=true); try{await fn(); if(mounted)Navigator.pop(context);}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}finally{if(mounted)setState(()=>loading=false);} }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(register?'Registro':'Login')),body:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:420),child:Column(children:[
    const Icon(Icons.movie_filter,size:80), const SizedBox(height:20), TextField(controller:email,keyboardType:TextInputType.emailAddress,decoration:const InputDecoration(labelText:'Email')), const SizedBox(height:12), TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'Contraseña')), const SizedBox(height:18),
    SizedBox(width:double.infinity,child:FilledButton(onPressed:loading?null:()=>run(() async{if(register){await auth.register(email.text.trim(),pass.text);}else{await auth.login(email.text.trim(),pass.text);}}),child:Text(register?'CREAR CUENTA':'INGRESAR'))),
    TextButton(onPressed:()=>setState(()=>register=!register),child:Text(register?'Ya tengo cuenta':'Crear cuenta nueva')),
    const Divider(height:32), SizedBox(width:double.infinity,child:OutlinedButton.icon(icon:const Icon(Icons.login),label:const Text('Continuar con Google'),onPressed:loading?null:()=>run(() async{await auth.signInWithGoogle();}))),
  ])))));
}
