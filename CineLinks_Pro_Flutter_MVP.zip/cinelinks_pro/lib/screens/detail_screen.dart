import 'package:flutter/material.dart';
import '../models/media_item.dart';
import '../services/firestore_service.dart';
import 'player_screen.dart';

class DetailScreen extends StatelessWidget {
  final MediaItem item;
  const DetailScreen({super.key, required this.item});

  @override Widget build(BuildContext context) {
    final service = FirestoreService();
    return Scaffold(
      body: CustomScrollView(slivers:[
        SliverAppBar(expandedHeight:430, pinned:true, flexibleSpace:FlexibleSpaceBar(background:Image.network(item.posterUrl, fit:BoxFit.cover, errorBuilder:(_,__,___)=>const Center(child:Icon(Icons.movie, size:80))))),
        SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.all(20), child:Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
          Text(item.title, style:const TextStyle(fontSize:30,fontWeight:FontWeight.w900)),
          const SizedBox(height:6), Text('${item.year} • ${item.genre} • ${item.category}', style:const TextStyle(color:Colors.white60)),
          const SizedBox(height:18), Text(item.description, style:const TextStyle(fontSize:16,height:1.5)),
          const SizedBox(height:24), SizedBox(width:double.infinity, child:FilledButton.icon(icon:const Icon(Icons.play_arrow), label:Text(item.premiumOnly ? 'VER AHORA • PREMIUM' : 'VER AHORA'), onPressed:() async {
            if (item.premiumOnly && !await service.isPremium()) {
              if (!context.mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Este enlace requiere Premium'))); return;
            }
            if (!context.mounted) return;
            Navigator.push(context, MaterialPageRoute(builder:(_)=>PlayerScreen(title:item.title, url:item.videoUrl)));
          })),
          const SizedBox(height:10), StreamBuilder<bool>(stream:service.isFavorite(item.id), builder:(_,snap)=>SizedBox(width:double.infinity, child:OutlinedButton.icon(icon:Icon(snap.data==true?Icons.favorite:Icons.favorite_border), label:Text(snap.data==true?'QUITAR DE FAVORITOS':'AGREGAR A FAVORITOS'), onPressed:() async { try { await service.toggleFavorite(item.id); } catch(e){ if(context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e'))); } }))),
        ])))
      ]),
    );
  }
}
