import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'theme/app_theme.dart';
import 'screens/home_screen.dart';
// Después de ejecutar `flutterfire configure`, descomenta:
// import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Reemplaza por:
  // await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await Firebase.initializeApp();
  runApp(const CineLinksProApp());
}

class CineLinksProApp extends StatelessWidget {
  const CineLinksProApp({super.key});
  @override Widget build(BuildContext context)=>MaterialApp(
    debugShowCheckedModeBanner:false,
    title:'CineLinks Pro',
    theme:AppTheme.dark,
    home:const HomeScreen(),
  );
}
