# CineLinks Pro

MVP Flutter para Android/iOS con diseño oscuro tipo streaming, Firebase Auth + Firestore, favoritos, reproductor interno y panel admin.

## 1. Crear el proyecto nativo Flutter
Si quieres conservar estas carpetas `lib/` y `firebase/`, desde una carpeta nueva ejecuta `flutter create .` y luego copia estos archivos encima. También puedes ejecutar `flutter create cinelinks_pro` y reemplazar `pubspec.yaml` y `lib/`.

## 2. Firebase
1. Instala Firebase CLI y FlutterFire CLI.
2. `firebase login`
3. `dart pub global activate flutterfire_cli`
4. En la raíz del proyecto: `flutterfire configure`
5. Habilita Authentication > Email/Password y Google.
6. Crea Cloud Firestore.
7. Sustituye en `lib/main.dart` `Firebase.initializeApp()` por:
   `Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform)`
   e importa `firebase_options.dart`.
8. Publica `firebase/firestore.rules` como reglas de Firestore.

## 3. Rol administrador
Después de registrarte, crea/edita `users/{TU_UID}` en Firestore:
```json
{
  "role": "admin",
  "plan": "premium",
  "email": "tu@email.com"
}
```
Para usuarios normales usa `role: user` y `plan: free`.

## 4. Colección media
Cada documento contiene:
- title
- description
- posterUrl
- videoUrl
- category: Películas | Series | Anime | Documentales
- genre
- year
- premiumOnly
- createdAt

## 5. Pagos
La pantalla Premium incluye los dos botones y la UX, pero la creación/captura real del pago debe hacerse en backend (por ejemplo Firebase Cloud Functions). Nunca embebas secretos privados de Mercado Pago o PayPal en Flutter.

Flujo recomendado:
- App -> Cloud Function `createCheckout`
- Backend -> Mercado Pago / PayPal con credenciales privadas
- Proveedor -> webhook al backend
- Backend valida pago y actualiza `users/{uid}.plan = premium`

## 6. Nota de contenido
Usa únicamente URLs de video que tengas derecho a distribuir/reproducir. Para HLS/DASH o DRM conviene ampliar el reproductor y la infraestructura.
